<?php declare(strict_types=1);

namespace PhpParser\Node\Expr;

require __DIR__ . '/../ClosureUse.php';

if (false) {
    /**
     * For classmap-authoritative support.
     *
     * @deprecated use \PhpParser\Node\ClosureUse instead.
     */
    class ClosureUse extends \PhpParser\Node\ClosureUse {
    }
}
